import java.util.Scanner;
import java.util.Random;

public class Mastermind {

	public static Scanner sc = new Scanner(System.in);
	public static Random r = new Random();
	public static int rand;
	public static int[] answer;
	public static int[] guess;
	
	public static void main(String[] args) {
		System.out.println("Welcome to the Game of Mastermind!\r\n"
				+ "\r\n"
				+ "I will create a answer code using different coloured pegs. You must answer the \nanswer code in as few answeres as possible. After each answer you will get a clue \nfor how many correct pegs and how many correct colors your answer contained.\r\n"
				+ "");

		int pegs = 0;
		int colors = 0;
		
		while (pegs < 2 || pegs > 8) {
			System.out.print("Enter the number of pegs (2-8): ");
			pegs = sc.nextInt();
			
			if (pegs < 2 || pegs > 8) {
				System.out.println("Invalid input");
			}
			
		}
		
		while (colors < 3 || colors > 10) {
			System.out.print("Enter the number of colors (3-10): ");
			colors = sc.nextInt();
			
			if (colors < 3 || colors > 10) {
				System.out.println("Invalid input");
			}
			
		}
		
		answer = new int[pegs];
		
		getCode(colors, answer);
		
		int round = 0;
		
		//game loop
		while (true) {
			round++;
			guess = new int[pegs];
			
			System.out.printf("Guess #%d", round);
			System.out.println();
			
			for (int i = 0; i<pegs; i++) {
				System.out.printf("Color for peg %d: ", i+1);
				int input = sc.nextInt();
				guess[i] = input;
			}
			
			getClues();
			
			if (checkWin(answer, guess)) {
				System.out.printf("You guessed the code in %d turns.", round);
				System.out.println();
				System.out.println("Thanks for playing!");
				break;
			}
		}

		
	}

	/**
	 * checks for a correct guess sequence by comparing two arrays
	 * @param answer is answer array provided
	 * @param guess is user's input array
	 * @return
	 */
	static boolean checkWin(int[] answer, int[] guess) {
		boolean win = true;
		for (int i = 0; i<answer.length; i++) {
			if (answer[i] != guess[i]) {
				win = false;
				break;
			}
		}
		
		return win;
	}
	
	/**
	 * provides user clues about right and wrong input
	 */
	static void getClues() {
		int pegsRight = 0;
		int colorsRight = 0;
		
		//pegs correct
		for (int i = 0; i<guess.length; i++) {
			if (guess[i] == answer[i]) {
				pegsRight++;
			}
		}
		
		//colors correct
		for (int j = 0; j<answer.length; j++) {
			for (int i = 0; i<guess.length; i++) {
				if (answer[j] == guess[i]) {
					colorsRight++;
					break;
				}
			}
		}
		
		System.out.printf("You have %d peg(s) correct and %d color(s) correct.", pegsRight, colorsRight);
		System.out.println();
	}
	
	
	
	
	/**
	 * create random unique numbers and intsert into a provided array
	 * @param colors is numbers to choose from
	 * @param answer is the array provided for insertion
	 */
	static void getCode(int colors, int[] answer) {
		for (int j = 0; j<answer.length; j++) {
			boolean inList = true;
			
			while (inList) {
				rand = r.nextInt(colors)+1;
				inList = false;
				
				for (int i = 0; i < j; i++) {
					if (answer[i] == rand) {
						inList = true;
						break;
					}
				}
			}
			
			answer[j] = rand;
		}
		
		for (int i = 0; i<answer.length; i++) {
			System.out.println(answer[i]);
		}
	}
}
