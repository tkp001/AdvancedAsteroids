import java.util.Random;
public class WhileLoop {
	public static void main(String[] args) {
		Random r = new Random();
		int guessMe = 7;
		int number = -1;
		
		while (guessMe != number) {
			number = r.nextInt(9) +1;
			if (guessMe != number) {
				System.out.println(number);
				
				if (guessMe > number ) {
					System.out.println("Low guess");
				} else {
					System.out.println("High guess");
				}
				
				
			} else {
				System.out.println("Found it!");
			}
		}
		
	}
}
