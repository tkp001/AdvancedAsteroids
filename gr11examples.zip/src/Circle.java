import java.util.Random;

public class Circle {
	Random r = new Random();
	//variables
	int i1;
	int i2;
	
	//constructor
	Circle() {
		i1 = 0;
		i2 = 0;
	}
	
	//methods
	void newNumbers() {
		i1 = r.nextInt(21);
		i2 = r.nextInt(21);
	}
	
	int Sum() {
		return i1+i2;
	}
	
	String Equation() {
		String z = String.valueOf(i1) + " + " + String.valueOf(i2);
		return z;
	}
}
