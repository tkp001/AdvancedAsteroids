import java.util.Scanner;
public class EscapeSequence {

	public static void main(String[] args) {
		int secret = 9;
		Scanner sc = new Scanner(System.in);
		
		int total = 0;
		int i = 0;
		while (true) {
			
			System.out.print("Enter a test score [999 to quit]: ");
			int x = sc.nextInt();
			
			if (x == 999) {
				break;
			}
			
			
			
			i++;
			total = total+x;
			
			
		
		}
		
		System.out.println(total/i);
		
	}

}
