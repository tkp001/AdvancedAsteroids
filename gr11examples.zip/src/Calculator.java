import java.util.Scanner;



public class Calculator {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		
		
		
		System.out.print("Enter a number: ");
		double input1 = read.nextDouble();
		
		System.out.print("Enter a number: ");
		double input2 = read.nextDouble();
		
		read.close();

		
		//calculation
		// sum, difference, product, and quotient + remainder
		
		System.out.println(input1 + input2);
		System.out.println(input1 - input2);
		System.out.println(input1 * input2);
		System.out.println(input1 / input2);
		System.out.println(input1 % input2);
		

	}

}
