import java.util.Scanner;
import java.lang.Math;

public class JavaQuizReview {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		
		System.out.print("Enter side a: ");
		double a = read.nextDouble();
		
		System.out.print("Enter side b: ");
		double b = read.nextDouble();
		
		double c = Math.sqrt(a*a + b*b);

		

	}

}
//
//
//Create a CircleCalculator application that prompts the diameter of a circle, then calculates and displays the radius, the area, and the circumference of the circle.  Make sure to use variables and constants in your program.
