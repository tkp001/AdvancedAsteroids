
public class AboutMe {

	public static void main(String[] args) {
		String name = "Henry Martell";
		String favoriteSport = "baseball";
		String favoriteSport2 = "hockey";
		
		//
		
		System.out.println("Hello!");
		System.out.println("My name is " + name);
		System.out.println("I have 3 sisters and 4 brothers");
		System.out.println("I play " + favoriteSport + " and " + favoriteSport2 );
		System.out.println("My favourite band is Metallica");

		
		System.out.println("CLASS SCHEDULE");
		System.out.print("P1");
		System.out.println("\t Computer Science");
		System.out.print("P2");
		System.out.println("\t English");
		System.out.print("P3");
		System.out.println("\t Music");
		System.out.print("P4");
		System.out.println("\t Biology");
		
		
		System.out.println("\\(\")/");
		System.out.println("  ==");
		System.out.println("  ||");
		System.out.println("  /\\");
		System.out.println("_/  \\_");
		
		
	}

}


/* 

\(")/
  ==
  ||
  /\
_/  \_



 */