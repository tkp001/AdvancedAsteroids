
public class VariablesPractice 
{

	public static void main(String[] args) 
	{
		//Type your response to Q7 on the next line.
		String name = "Tanush";
		
		//Type your response to Q8 on the next line.
		int numSiblings = 1;
		
		//Type your response to Q9 on the next line.
		String hobby = "badminton";
		
		//Type your response to Q10 on the next line.
		char symbol = '0';
		
		//Type your response to Q11 on the next line.
		double number = 3.14159;
		
		System.out.println("Hello!");
		System.out.println("My name is " + name);
		System.out.println("I have " + numSiblings + " siblings");
		System.out.println("I like to play " + hobby);
		System.out.println("My favourite symbol is " + symbol);
		System.out.println("My favourite number is " + number);

	}

}
