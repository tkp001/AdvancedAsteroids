/*
 * Tanush Pandya
 * Mr. Campbell
 * Sept 20, 2024
 * Input in Java
 *  
 * */


import java.util.Scanner;

public class InputInJava {
  public static void main(String[] args) {
	  
	Scanner myInput = new Scanner(System.in);
	
	System.out.println("Enter name:");
	String name = myInput.nextLine();
	
	System.out.println("Enter number:");
	int age = myInput.nextInt();
	
	
	System.out.println("What is 1+1 (Hint, its not 11!!!!):");
	int answer = myInput.nextInt();
	
	
	System.out.println(name);
	System.out.println(age);
	System.out.println(answer);
	myInput.close();
    
  }
}
