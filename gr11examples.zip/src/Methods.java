
public class Methods {

	public static void main(String[] args) {
		

	}
	
	static void addRoof(int l, int w, char s) {
		
		
		
	}

}
