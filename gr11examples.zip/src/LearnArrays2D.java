import java.util.Random;


public class LearnArrays2D {

	public static void main(String[] args) {
		
		
	}

}
