import java.lang.Math;



public class BasicMath {

	public static void main(String[] args) {
		double a = 39.0/8.0;
		System.out.println(a);

		

	}

}
