
public class ifelse {

	public static void main(String[] args) {
		int secret = 4;
		int guess = 2;
		
		if (secret == guess) {
			System.out.println("right guess");
		} else if (secret > guess) {
			System.out.println("guess too low");
			
		} else if (guess > secret) {
			System.out.println("guess too high");
		}
	}

}
