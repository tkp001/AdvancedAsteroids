import java.util.Scanner;

public class CircleMain {

	public static void main(String[] args) {
		Circle Adder = new Circle();
		int tries = 3;
		int pts = 0;
		
		
		while (tries > 3) {
			Adder.newNumbers();
			System.out.println();
			tries++;
		}
		
	}
	
}
