import java.util.Scanner;


public class JavaEats {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in); 
		
		//information for user
		System.out.println("Welcome to Java Eats, a coffee themed delivery app");
		System.out.println("=============================================================");
		System.out.println();
		System.out.println("A cheeseburger and fries for $8.99");
		System.out.println("A falafel and rice plate for $9.99");
		System.out.println("A Greek salad supreme for $8.49");
		System.out.println("A personal pan pizza for $7.99");
		System.out.println("Drinks are $2.49 each");
		
		System.out.println("Along with the above prices, there is a 13% sales tax on every order. The delivery fee of $5.00 is added after tax.");
		
		System.out.println();
		System.out.println("=============================================================");
		System.out.println("Let’s get your order together for you. Please indicate how many of each food item you would like to order. If you do not want an item, please enter 0.\r\n");
		
		
		System.out.println();
		System.out.println("Options:");
		System.out.println("=============================================================");
		
		//input for ordering
		
		System.out.print("Cheeseburger and Fries: ");
		int cf = read.nextInt();
		
		System.out.print("Falafel and Rice Plate: ");
		int frp = read.nextInt();
		
		System.out.print("Greek Salad Supreme: ");
		int gss = read.nextInt();
		
		System.out.print("Personal Pizza: ");
		int pp = read.nextInt();
		
		System.out.print("Drinks: ");
		int d = read.nextInt();
		
		System.out.println("=============================================================");
		double total = 8.99*cf + 9.99*frp + 8.49*gss + 7.99*pp + 2.49*d; 
		total = total*1.13;
		total += 5;
		
		
		//print total
		System.out.printf("With tax and delivery, your order total is $%.2f", total);
		System.out.println();
		System.out.println("Thank you for ordering with Java Eats!\r\n");
		
		
		read.close();
		
	}
}
