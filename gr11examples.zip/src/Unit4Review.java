import java.util.*;

public class Unit4Review {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String alp = "abcdefghijklmnopqrstuvwxyz";
		//fix spaces
		String ipt = "";
		
		
		do {
			System.out.print("Enter a message to encrypt/decrypt (or QUIT): ");
			ipt = sc.nextLine();
			
			if (!ipt.toUpperCase().equals("QUIT")) {
				String[] splitphrase = new String[ipt.length()];
				splitphrase = ipt.split("");
				
				String[] cipher = splitphrase;
				
				for (int i = 0; i<cipher.length; i++) {
					int x = alp.indexOf(cipher[i]);
					
					if (x != -1) {
						x = (x+13) % alp.length();
						cipher[i] = alp.substring(x,x+1);
					}
					
				}
				
				for (String i: cipher) {
					System.out.print(i);
					
				}
				System.out.println();
			}
			
			
			
		} while (!ipt.equals("quit"));
		
		System.out.println("Goodbye!");
	}

}
