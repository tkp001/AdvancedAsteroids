import java.util.Scanner;

public class Strings {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter your first name: ");
		
		String b = "ski";
		
		while (b.length() < 8) {
			System.out.print("Enter a password that is at least 8 characters: ");
			b = sc.next();
		}
		
		System.out.println(b.substring(0,3));
		System.out.println(b.substring(b.length()-3,b.length()));
//		System.out.println(b.substring(b.length()/2-1, b.substring(b.length()/2+1)));

		
	}

}
