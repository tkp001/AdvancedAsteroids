import java.util.Scanner;

public class Strings2 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter your first name: ");
		char a = sc.next().toLowerCase().charAt(0);
		
		System.out.print("Enter your middle inital: ");
		char b = sc.next().toUpperCase().charAt(0);
		
		System.out.print("Enter your last name: ");
		char c = sc.next().toLowerCase().charAt(0);

		System.out.printf("Your Monogram is: %s%s%s", String.valueOf(a),String.valueOf(b),String.valueOf(c));
	}

}