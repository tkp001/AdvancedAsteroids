/*
 * Tanush Pandya
 * October 8, 2024
 * Mr Campbell
 * A simple calculator program
 */

import java.lang.Math;
import java.util.Scanner;

public class TheSimpleCalculator {
	public static void main(String[] args) {
		double n1 = 0, n2 = 0, n3 = 0, answer = -1; ///placeholders
		Scanner sc = new Scanner(System.in);
		
		System.out.println("WELCOME TO THE SIMPLE CALCULATOR APPLICATION");
		System.out.println("=============================================");
		System.out.println("1. Addition			5. Exponentiation");
		System.out.println("2. Subtraction			6. Average");
		System.out.println("3. Multiplication		7. Sine");
		System.out.println("4. Division			8. Cosine");
		System.out.println("=============================================");
		System.out.print("Which operation would you like to perform? ");
		int operation = sc.nextInt();
		System.out.println("=============================================");
		
		//figure out how much input to ask for
		switch (operation) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:
				System.out.print("Enter the first number: ");
				n1 = sc.nextDouble();
				System.out.print("Enter the second number: ");
				n2 = sc.nextDouble();
				break;
			case 6:
				System.out.print("Enter the first number: ");
				n1 = sc.nextDouble();
				System.out.print("Enter the second number: ");
				n2 = sc.nextDouble();
				System.out.print("Enter the third number: ");
				n3 = sc.nextDouble();
				break;
			case 7:
			case 8:
				System.out.print("Enter the number in degrees: ");
				n1 = sc.nextDouble();
				break;
			default:
				System.out.println("Invalid choice");
				break;
		}
		
		//calculate and print answer
		switch (operation) {
			case 1: answer = n1 + n2; break;
			case 2: answer = n1 - n2; break;
			case 3: answer = n1 * n2; break;
			case 4: answer = n1 / n2; break;
			case 5: answer = Math.pow(n1, n2); break;
			case 6:
				answer = n1 + n2 + n3;
				answer = answer/3;
				break;
			case 7:
				n1 = Math.toRadians(n1);
				n1 = Math.sin(n1);
				answer = n1;
				break;
			case 8:
				n1 = Math.toRadians(n1);
				n1 = Math.cos(n1);
				answer = n1;
				break;
			default: break;
		}
		if (operation >= 1 && operation <= 8) {
			System.out.println("=============================================");
			System.out.println("The answer is: " + answer);
		}
		
		sc.close();
	}
}
