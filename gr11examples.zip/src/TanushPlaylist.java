/*
 * Tanush Pandya
 * Mr. Campbell
 * November 28, 2024
 * Spotify Playlist Assignment
 * EXTENSION FOR LEVEL 5 (shuffle)
 */

import java.util.*;

public class TanushPlaylist {
	static ArrayList<Song> Playlist = new ArrayList<Song>();
	static Scanner sc = new Scanner(System.in);
	
	public static void main(String[] args) {
		int choice;
	
		//demo songs
		Playlist.add(new Song("Shape of You", "Ed Sheeran", 2017));
		Playlist.add(new Song("Enter Sandman", "Metallica", 1991));
		Playlist.add(new Song("Blinding Lights", "The Weeknd", 2019));
		Playlist.add(new Song("Man! I Feel Like a Woman", "Shania Twain", 1997));
		
		//main loop
		do {
			System.out.println("1. Add a song");
			System.out.println("2. Remove a song");
			System.out.println("3. Show Playlist");
			System.out.println("4. Quit");
			System.out.println("5. Shuffle");
			
			choice = 0;
			while (choice > 5 || choice < 1) {
				System.out.print("Choose an option: ");
				choice = sc.nextInt();
				if (choice > 5 || choice < 1) {
					System.out.println("Invalid choice, try again!");
				}
			}
			System.out.println();
			
			//choose method based on user input
			switch(choice) {
				case 1: 
					addSong();
					continue;
				case 2: 
					removeSong();
					continue;
				case 3: 
					displayPlaylist();
					continue;
				case 4:
					break;
				case 5:
					shufflePlaylist();
					continue;
				default:
					break;
			}
					
		} while (choice != 5);

		System.out.println("End of program.");
		sc.close();
	}
	
	/**
	 * Add user's desired song to the playlist
	 */
	static void addSong() {
		String extra = sc.nextLine();
		
		System.out.print("Enter song title: ");
		String title = sc.nextLine();
		System.out.print("Enter song artist: ");
		String artist = sc.nextLine();
		System.out.print("Enter song year: ");
		int year = sc.nextInt();
		
		System.out.println();
		Playlist.add(new Song(title, artist, year));
		System.out.println("Song added");
		System.out.println();
	}
	
	/**
	 * Remove user's desired song to the playlist
	 */
	static void removeSong() {
		int ipt = 0;
		
		while (ipt < 1 || ipt > Playlist.size()) {
			System.out.print("Enter song index in playlist: ");
			ipt = sc.nextInt();
			if (ipt < 1 || ipt > Playlist.size()) {
				System.out.println("Invalid index, try again!");
			}
		}
		
		Playlist.remove(ipt-1);
		System.out.println("Song removed");
		System.out.println();
		
	}
	
	/**
	 * Display all songs in the playlist
	 */
	static void displayPlaylist() {
		for (int i = 0; i<Playlist.size(); i++) {
			Song a = Playlist.get(i);
			System.out.printf("%d.", i+1);
			a.displayDetails();
		}
		System.out.println();
	}

	/**
	 * Shuffle the playlsit
	 */
	static void shufflePlaylist() {
		Random r = new Random();
		for (int i = 0; i<Playlist.size(); i++) {
			int val = r.nextInt(Playlist.size())+1;
			Song a = Playlist.get(i);
			Playlist.remove(i);
			Playlist.add(val, a); 
		}
		
		System.out.println("Shuffle completed");
		System.out.println();
	}
	
}
