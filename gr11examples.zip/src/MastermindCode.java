
public class MastermindCode {
	/**
	 * Attributes
	 */
	private int pegs, colors;
	private String value;
	
	/**
	 * Constructor
	 * @param p number of pegs
	 * @param c number of colors
	 */
	MastermindCode (int p, int c) {
		pegs = p;
		colors = c;
		value = "";
		setValue();
	}
	
	/**
	 * Setter Methods
	 */
	
	/**
	 * Generate a random value for the code
	 * ensure each digit in code is unique
	 */
	void setValue() {
		String code = "";
		final String VALUES = "1234567890";
		
		do {
			int index = (int)(Math.random()*colors);
			String digit = VALUES.substring(index, index+1);
			if (code.indexOf(digit) < 0) {
				code = code + digit;
			} else {
				continue;
			}
			
		} while (code.length() < pegs);
		
		value = code;
	}
	
	void setPegs(int p) {
		pegs = p;
	}
	
	void setColors(int c) {
		colors = c;
	}
	
	
	/**
	 * Getter Methods
	 */
	String getValue() {return value;}
	int getPegs() {return pegs;}
	int getColors() {return colors;}
	
	
	boolean equals(String guess) {
		return value.equalsIgnoreCase(guess);
	}

	/**
	 * Display Method
	 */
	void showClues(String guess) {
		int p = 0, c = 0;
		for (int i = 0; i < guess.length(); i++) {
			//Count the correct pegs first
			if (guess.charAt(i) == value.charAt(i)) p++;
			//Count correct colors
			else if (value.indexOf(guess.substring(i,i+1)) >= 0) c++;
		}
		
		//Display the clue
		System.out.printf("You have %d peg(s) correct and %d color(s) correct.%n", p, c);
	}

	
	
}
