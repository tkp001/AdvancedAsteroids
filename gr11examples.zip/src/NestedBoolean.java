import java.util.Scanner;



public class NestedBoolean {

	public static void main(String[] args) {		
		Scanner sc = new Scanner(System.in);
		int largest = 0;
		
		System.out.print("Enter first number number: ");
		int a = sc.nextInt();

		System.out.print("Enter first second number: ");
		int b = sc.nextInt();
		
		System.out.print("Enter first third number: ");
		int c = sc.nextInt();
		
		if (a > b && a > c) {
			System.out.println("a is the largest");
			largest = a;
		} else if (b > a && b > c) {
			System.out.println("b is the largest");
			largest = b;
		} else {
			System.out.println("c is the largest");
			largest = c;
		}
		
		System.out.println(largest);
	}

}
