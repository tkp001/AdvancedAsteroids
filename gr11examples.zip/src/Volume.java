import java.util.Scanner;
import java.lang.Math;


public class Volume {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		
		
		System.out.print("Enter side value: ");
		double side = read.nextDouble();
		
		double answer = Math.pow(side, 3);
		System.out.println(answer);
	}

}
