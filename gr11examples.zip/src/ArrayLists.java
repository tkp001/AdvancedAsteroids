import java.util.*;

public class ArrayLists {

	public static void main(String[] args) {
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		Scanner sc = new Scanner(System.in);
		int ans = 0;
		numbers.add(0);
		
		do {
			System.out.print("Enter a test score (999 to quit): ");
			ans = sc.nextInt();
			
			if (ans != 999) {
				for (int i = 0; i<numbers.size(); i++) {
					if (numbers.get(i) < ans) {
						numbers.add(i, ans);
						break;
					}
				}
			}
			
		} while (ans != 999);
		
		System.out.println(numbers);
		
	}

}
