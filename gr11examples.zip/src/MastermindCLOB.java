/*
 * Mastermind Class Objects
 * Mastermind using different method
 * Tanush P
 * Nov 25, 2024
 */

import java.util.Scanner;

public class MastermindCLOB {

	public static void main(String[] args) {
		//initialization
		Scanner sc = new Scanner(System.in);
		MastermindCode code;
		int pegs = 0, colors = 0, turn = 0;
		String guess = "";
		
		
		System.out.println("Welcome to the Game of Mastermind, you.... already know the rules!");
		
		while (pegs < 2 || pegs > 8) {
			System.out.print("Enter the number of pegs (2-8): ");
			pegs = sc.nextInt();
			
			if (pegs < 2 || pegs > 8) {
				System.out.println("Invalid input");
			}
			
		}
		
		while (colors < 3 || colors > 10) {
			System.out.print("Enter the number of colors (3-10): ");
			colors = sc.nextInt();
			
			if (colors < 3 || colors > 10) {
				System.out.println("Invalid input");
			}
			
		}
		
		//instantiate
		//instance of class
		
		code = new MastermindCode(pegs, colors);
		
		
		//game loop
		while (!code.equals(guess)) {
			turn++;
			guess = "";
			
			System.out.printf("Guess #%d", turn);
			System.out.println();
			
			for (int i = 0; i<pegs; i++) {
				System.out.printf("Color for peg %d: ", i+1);
				int input = sc.nextInt();
				guess = input+guess;
			}
			
			code.showClues(guess);
			
			if (code.equals(guess)) {
				System.out.printf("You guessed the code in %d turns.", turn);
				System.out.println();
				System.out.println("Thanks for playing!");
				break;
			}
		}

	}

}
