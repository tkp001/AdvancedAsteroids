import java.util.Scanner;
import java.util.Random;

public class ChoHan {

	public static void main(String[] args) {
		System.out.println("The Game of Cho-Han\r\n"
				+ "======================================================\r\n"
				+ "HOW TO PLAY:\r\n"
				+ "2 dice are rolled. You must choose whether you think\r\n"
				+ "the total is even (cho) or odd (han). If you are\r\n"
				+ "correct, you will win 10 points. If you are incorrect,\r\n"
				+ "you lose 10 points.\r\n"
				+ "======================================================\r\n");
		
		Scanner sc = new Scanner(System.in);
		Random r = new Random();
		
		int d1, d2;
		int pts = 50;
		
		while (true) {
			d1 = r.nextInt(6)+1;
			d2 = r.nextInt(6)+1;
			int dtotal = d1+d2;
			
			System.out.printf("You have %d points \n", pts);
			System.out.println("You swirl the cup and hear the rattle of dice...\r\n"
					+ "You slam the cup on the floor, still covering the dice.\r\n"
					+ "======================================================\r\n"
					+ "");
			
			System.out.print("CHO (even) or HAN (odd): ");
			String ans = sc.next();
			System.out.println("======================================================");
			System.out.println("You lift the cup to reveal...");
			System.out.printf("%d + %d = %d", d1, d2, dtotal);
			System.out.println();
			
			if (ans.equals("CHO") && dtotal%2 == 0) {
				System.out.println("You win 10 points!");
				pts = pts+10;
			}  else if (ans.equals("HAN") && dtotal%2 == 1) {
				System.out.println("You win 10 points!");
				pts = pts+10;
			} else {
				System.out.println("You lose 10 points!");
				pts = pts-10;
			}
			
			System.out.println();
			System.out.print("Would you like to play again [y/n]: ");
			ans = sc.next();
			System.out.println("======================================================");
			
			if (ans.equals("n")) {
				break;
			}
			
			
		}
		
		System.out.println("Thank you for playing Cho-Han.");
		System.out.printf("You finishde the game with $d points. \n", pts);
		sc.close();
	}

}