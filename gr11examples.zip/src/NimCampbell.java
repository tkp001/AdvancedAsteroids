/*
 * USE HEADER AND METHOD COMMENTS
 */

import java.util.Scanner;
import java.util.Random;

public class NimCampbell {
	//global vars
	public static int numStones;
	public static Scanner sc = new Scanner(System.in);
	public static Random r = new Random();
	
	
	public static void main(String[] args) {
		// set up var and objs
		Boolean play = true;
		
		//display titles and rules
		System.out.println("Welcome to the game of Nim.\r\n"
				+ "There will be 15 - 30 stones selected for a game.\r\n"
				+ "You will take turns with your opponent drawing stones. Whoever draws the last stone loses.\r\n"
				+ "You can draw 1, 2, or 3 stones. You cannot draw more stones than there are left in the game.\r\n"
				+ "");
		
		
		//game loop
			// set num of stones for game
		
			//players turn
			//check loss
		
			//comouters turn
			//check loss
		
			//replay or quit
		
		//goodbye message
		
		
		while (play) {
			numStones = r.nextInt(16)+15;
			drawLine();
			
			while (numStones > 0) {
				playerTurn();
				
				if (checkLoss()) {
					System.out.println("You took the last stone, you lose!");
					break;
				}
				
				compTurn();
				
				if (checkLoss()) {
					System.out.println("The computer took the last stone, you win!");
					break;
				}
			}
			
			
			
			
			
			
			
			while (true) {
				System.out.print("Would you like to play again? [Q for quit][Y for yes]: ");
				String choice = sc.next();
				if (choice.equals("Q") || choice.equals("q")) {
					play = false;
					break;
				} else if (choice.equals("Y") || choice.equals("y")) {
					play = true;
					break;
				} else {
					System.out.println("Invalid option!");
				}
			}
			drawLine();
		}
		System.out.println("Thanks for playing!!");
	}
	
	
	/**
	 * draw a line of 50 symbols
	 */
	public static void drawLine() {
		for (int i = 0; i < 50; i++) {
			System.out.print("-");
		}
		System.out.println();
	}
	
	/**
	 * to have the player write a number from 1 to 3 and update total stones accordingly
	 */
	public static void playerTurn() {
		//collect valid input
		int ans = 0;
		
		while (true) {
			System.out.printf("There are %d stones, Enter a value: ", numStones);
			ans = sc.nextInt();
			
			if (isValidMove(ans)) {
//				System.out.println("Good job!");
				break;
			} else {
				System.out.println("Invalid option.");
			}
		}
		
		//update value
		numStones -= ans;
	}

	public static void compTurn() {
		int ans = 0;
		
		while (true) {
			ans = r.nextInt(3)+1;
			
			if (isValidMove(ans)) {
				break;
			} else {
				System.out.println("loopstuck");
			}
		}
		
		//update value
		System.out.printf("There are %d stones. Your opponent takes %d stones.", numStones, ans);
		System.out.println("");
		numStones -= ans;
		
	}
	
	/**
	 * Determines if ans is a valid move or not
	 * @param ans the move to evaluate
	 * @return true or false, based on validity
	 */
	public static boolean isValidMove(int ans) {
		
		if (ans < 4 && ans > 0 && ans <= numStones) {
			return true;
		} else {
			return false;
		}
		
	}
	
	/**
	 * Determines if game is over
	 * @return true if no stones, false if there are stones
	 */
	public static boolean checkLoss() {
		if (numStones <= 0) {
			return true;
		} else {
			return false;
		}
	}
}
