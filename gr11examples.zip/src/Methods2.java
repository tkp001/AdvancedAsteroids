/**
 * Returns a word based on a number inputed
 * @param num and integer to be referenced for an array
 * @return a string word that represents the number in spanish
 * */

public class Methods2 {
	public static void main(String[] args) {
		System.out.println(add(4,2));		
	}
	
	
	static int add(int n1, int n2) {
		return n1+n2;
	}
	static double add(double n1, double n2) {
		return n1+n2;
	}
	static int sub(int n1, int n2) {
		return n1-n2;
	}
	static double sub(double n1, double n2) {
		return n1-n2;
	}
}
