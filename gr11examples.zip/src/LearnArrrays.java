import java.util.Scanner;
import java.util.Random;

public class LearnArrrays {

	public static void main(String[] args) {
		int[] even = new int[25];
		int[] odd = new int[25];
		int ei = 0;
		int oi = 0;
		int oddlen = 0;
		
		Random r = new Random();
		
		for (int i = 0; i < 26; i++) {
			int num = r.nextInt(100);
			
			if (num%2 == 0) {
				even[ei] = num;
				ei++;
			} else {
				odd[oi] = num;
				oi++;
			}
		}

		System.out.println("ODD:");
		for (int i = 0; i < odd.length; i++) {
			if (odd[i] == 0) {
				oddlen = i;
				break;
			}
			System.out.print(odd[i]);
			System.out.print(" ");

		}
		System.out.println();
		System.out.println("EVEN:");
		for (int i = 0; i < 25-oddlen; i++) {
//			if (even[i] == 0) {
//				break;
//			}
			System.out.print(even[i]);
			System.out.print(" ");
		}
	}

}
