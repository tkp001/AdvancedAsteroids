/*
 * Tanush Pandya
 * Mr. Campbell
 * November 28, 2024
 * Spotify Playlist Assignment
 */

public class Song {
	//initialization
	String title;
	String artist;
	int year;

	/**
	 * Constructor
	 * @title is the title of the song
	 * @artist is the artist of the song
	 * @year is the release date of the song
	 */
	Song(String title, String artist, int year) {
		this.title = title;
		this.artist = artist;
		this.year = year;
	}
	
	/**
	 * Gets the song title
	 * @return the title of the song
	 */
	String getTitle() {return title;}
	
	/**
	 * Gets the artist name
	 * @return the name of the artist
	 */
	String getArtist() {return artist;}
	
	/**
	 * Gets the song release date
	 * @return the year associated with the song
	 */
	int getYear() {return year;}
	
	/**
	 * Prints out the song information to the user
	 */
	void displayDetails() {
		System.out.printf("%s by %s, released %d", title, artist, year);
		System.out.println();

	}
	
	
	boolean compareSong(Song a) {
		if (this.title.equals(a.title)) {
			if (this.artist.equals(a.artist)) {
				if (this.year == a.year) {
					return true;
				}
			}
		}
		return false;
	}

}
