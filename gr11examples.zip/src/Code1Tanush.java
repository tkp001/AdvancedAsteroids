/*
 * Code1Tanush
 * Tanush Pandya
 * October 1, 2024
 * Write and implement basic Java. This includes input, output, and creating and manipulating simple data.
*/

import java.util.Scanner;
import java.lang.Math;


public class Code1Tanush {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int x, y, z;
		String name;
		double answer, average;
		String word = "pizza";
		
		//part 1
		System.out.println("Part 1");
		System.out.print("Enter your first test score: ");
		x = sc.nextInt();
		
		System.out.print("Enter your second test score: ");
		y = sc.nextInt();
		
		System.out.print("Enter your third test score: ");
		z = sc.nextInt();
		
		//calculate average
		average = (x+y+z)/3.0;
		//print to 2 decimals
		System.out.printf("Your average test score is %.2f", average);
		System.out.println();
		System.out.println();
		
		//part 2
		System.out.println("Part 2");
		//set answer to equation
		answer = Math.sqrt(Math.pow((3.5+2.6), 5)) + (22.0/7.0);
		//print to 3 decimals
		System.out.printf("%.3f", answer);
		System.out.println();
		System.out.println();
		
		
		System.out.println("Part 3");
		System.out.print("What is your full name? ");
		
		//fix scanner bug to allow String input
		name = sc.nextLine();
		name = sc.nextLine();
		
		//combine name and word in printf statement
		System.out.printf("%s, did you know that I love %s?", name, word);
	
		sc.close();
		
		
	}

}
