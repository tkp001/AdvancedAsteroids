import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("enter number: ");
		int x = sc.nextInt();
		int i = 2;
		
		while (i<x) {
			System.out.println(i);
			
			if (x%i == 0) {
				System.out.println("NOT PRIME");
				break;
			} else {
				System.out.println("PRIME");
			}
			i++;
		}
		
	}

}
