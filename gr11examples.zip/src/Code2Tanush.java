/*
 * Tanush Pandya
 * Mr. Campbell
 * October 23, 2024
 * Rock Paper Scissors
 * Level 5 Extension (#1)
 */

import java.util.Scanner;
import java.util.Random;

public class Code2Tanush {

	public static void main(String[] args) {
		
		System.out.println("Let’s Play Rock Paper Scissors!!");
		
		//game
		
		// inital values used throughout program
		boolean game = true;
		int gamesPlayed = 0;
		int gamesWon = 0;
		int gamesLost = 0;
		int gamesTied = 0;
		int rockThrow = 0;
		int paperThrow = 0;
		int scissorThrow = 0;
		
		//main loop
		while (game) {
			Scanner sc = new Scanner(System.in);
			Random r = new Random();
			System.out.println("====================================================");
			System.out.println("Choose your throw: 1 = ROCK, 2 = PAPER, 3 = SCISSORS");
			
			int pick = 0;
			while (pick > 3 || pick < 1) {
				System.out.print("You choose: ");
				pick = sc.nextInt();
				
				if (pick > 0 && pick < 4) {
					System.out.println("");
				} else {
					System.out.println("Invalid Input! Type again!");
				}
			}
				
			int computerPick = r.nextInt(3) + 1;
			
			// get string values to print comparison statement
			String a, b;
			if (pick == 1) {
				a = "ROCK";
				rockThrow++;
			} else if (pick == 2) {
				a = "PAPER";
				paperThrow++;
			} else {
				a = "SCISSORS";
				scissorThrow++;
			}
			if (computerPick == 1) {
				b = "ROCK";
			} else if (computerPick == 2) {
				b = "PAPER";
			} else {
				b = "SCISSORS";
			}
			
			System.out.printf("%s vs. ... %s!", a, b);
			System.out.println("");
			
			// winner logic 
			int winner = 0;
			if (pick == computerPick) {
				winner = 0; // tie!
			} else if (pick == 1 && computerPick == 3 ) {
				winner = 1;
			} else if (pick == 3 && computerPick == 2 ) {
				winner = 1;
			} else if (pick == 2 && computerPick == 1 ) {
				winner = 1;
			} else {
				winner = 2;
			}
			
			//display winner
			if (winner == 1) {
				System.out.println("You win!");
				gamesWon++;
			} else if (winner == 2) {
				System.out.println("You lost.");
				gamesLost++;
			} else {
				System.out.println("Its a tie!!");
				gamesTied++;
			}
		
			gamesPlayed++;
			
			String playAgain = "Temporary";
			while (!playAgain.equals("y") || !playAgain.equals("n")) {
				System.out.print("Would you like to play again? [y]es or [n]o: ");
				playAgain = sc.next();
				
				if (playAgain.equals("y") || playAgain.equals("n")) {
					System.out.println("");
					
					if (playAgain.equals("n")) {
						game = false;
					}
					break; // break if good input
					
				} else {
					System.out.println("Invalid Input! Type again!");
				}
			}
			
			
		}
			
			
		System.out.println("====================================================");
		System.out.println("Thanks for playing!");
		System.out.println("--------------------Statistics--------------------");
		System.out.println("Total games played: " + gamesPlayed);
		
		System.out.printf("Ratio of win to lose to tie: %.2f, %.2f, %.2f", (double)gamesWon/(double)gamesPlayed*100, (double)gamesLost/(double)gamesPlayed*100, (double)gamesTied/(double)gamesPlayed*100);
		System.out.println("");
		
		String commonThrow = "None";
		if (rockThrow > paperThrow) {
			 commonThrow = "Rock";
			 if (rockThrow > scissorThrow) {
				 commonThrow = "Rock"; 
			 } else {
				 if (paperThrow > scissorThrow) {
					 commonThrow = "Paper"; 
				 } else commonThrow = "Scissor"; 
			 }
		}
		
		System.out.println("Player's most common throw: " + commonThrow);
		

	}

}
