/*
 * Code3Tanush
 * Tanush Pandya
 * Nov 19, 2024
 * Rainfall statistics program that will simulate recording average weekly rainfall amounts for a year.
 * Extension: generate random amount of rainy days
*/

import java.util.Random;

public class Code3Tanush {

	public static Random r = new Random();
	
	public static void main(String[] args) {
		int[] data = {0,0,0,0,0,0,0,0,0,0};
		
		//generate rainfall data
		for (int i = 0; i<52; i++) {
			//random amount of rainy days
			int number = generateRainfall(r.nextInt(6)+1);
			//counter
			data[(number/10)] += 1;
		}
		
		//display rainfall data
		int start = 0;
		int end = 9;
		
		for (int i = 0; i<10; i++) {
			System.out.printf("%d-%d mm ", start, end);
			
			//fix first line indentation
			if (start/10 == 0) {
				System.out.print("  ");
			}
			
			
			drawLine(data[start/10]);
			
			start += 10;
			end += 10;
		}
		
	}
	
	/**
	 * draws line of certain length using special character to represent a histogram bar
	 * @param length, determines the length of the bar
	 */
	public static void drawLine(int length) {
		for (int i = 0; i<length; i++) {
			System.out.print("*");
		}
		System.out.println();
	}

	/**
	 * calculates the average amount of rainfall for a certain amount of days
	 * @param days, amount of rainy days in a week
	 * @return average amount of rainfall in number of days
	 */
	public static int generateRainfall(int days) {
		int total = 0;
		for (int i = 0; i<days; i++) {
			total += r.nextInt(100);
		}
		int average = total/days;
		return average;
	}

}
