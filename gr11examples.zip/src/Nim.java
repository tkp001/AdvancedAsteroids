import java.util.Scanner;
import java.util.Random;

public class Nim {
	
	
	
	public static void main(String[] args) {
		Random r = new Random();
		Scanner sc = new Scanner(System.in);
		int tokens;
		int turn;
		boolean game = true;
		
		
		System.out.println("Welcome to the game of Nim.\r\n"
				+ "There will be 15 - 30 stones selected for a game.\r\n"
				+ "You will take turns with your opponent drawing stones. Whoever draws the last stone loses.\r\n"
				+ "You can draw 1, 2, or 3 stones. You cannot draw more stones than there are left in the game.\r\n"
				+ "-------------------------------------------------------------------------------------\r\n");

		
		while (true) {
			tokens = r.nextInt(16) + 15;
			turn = 1;
			
			System.out.printf("Inital amount of tokens: %d", tokens);
			System.out.println();
			
			while (game) {
				if (turn ==1) {
					tokens = playerDraw(tokens);
					
					turn = 2;
				} else {
					tokens = compDraw(tokens);
					
					turn = 1;
				}
				
				//checkloss
				if (tokens == 1) {
					if (turn == 1) {
						System.out.println("You took the last stone - you lose!");	
					} else {
						System.out.println("Your opponent took the last stone - you win!");
					}
					game = false;
				}

			}
		
			
			
			
			System.out.print("Would you like to play again? Q to quit: ");
			String ans = sc.next();
			
			if (ans.equals("Q")) {
				System.out.println("-------------------------------------------------------------------------------------");
				System.out.println("Thanks for playing!");
				break;
			} else {
				System.out.println("-------------------------------------------------------------------------------------");
				game = true;
			}
			
		}
		
	}
	
	static int playerDraw(int tokens) {
		Scanner sc = new Scanner(System.in);
		int ans = 111112; // since not do while make first iteration false
		
		while (isValidMove(tokens, ans, 1)) {
			System.out.printf("There are %d tokens. How many would you like? ", tokens);
			ans = sc.nextInt();
			System.out.println("");
			
			if (tokens == 1) {
				ans = 0;
				break;	
			}
		}
		return tokens-ans;
	}
	
	static int compDraw(int tokens) {
		Random r = new Random();
		int ans = 111112;
		
		while (isValidMove(tokens, ans, 2)) {
//			ans = r.nextInt(3)+1;
			
			if (tokens % 3 == 0) {
				ans = 2;
			} else {
				if (tokens == 2) {
					ans = 1;
				} else {
					if (tokens % 2 == 0) {
						ans = 3;
					} else {
						ans = 1;
					}
				}
				
			}
			
			if (tokens == 1) {
				ans = 0;
				break;	
			}
		}
		
		System.out.printf("There are %d tokens. Your opponent takes %d tokens.", tokens, ans);
		System.out.println("");
		return tokens-ans;
	}

	static boolean isValidMove(int tokens, int ans, int turn) {
		if (ans < tokens) {
			if (ans > 0 && ans < 4) {
				return false;
			} else {
				if (turn == 1 && !(ans == 111112)) {
					System.out.println("Invalid selection, please try again.");
				}
				return true;
			}
		} else {
			if (turn == 1 && !(ans == 111112)) {
				System.out.println("Invalid selection, please try again.");
			}
			return true;
		}
	}
	
}
