import java.util.Scanner;
import java.lang.Math;

public class AverageSpeed {

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		
		System.out.print("Enter length: ");
		double length = read.nextDouble();
		
		System.out.print("Enter width: ");
		double width = read.nextDouble();
		
		System.out.print("Enter height: ");
		double height = read.nextDouble();
		
		double answer = length*width*height;
		System.out.printf("The volume of the box with lengths %.2f %.2f %.2f is %.2f", length, width, height, answer);
		
		//
		
		System.out.println();
		System.out.print("Enter side length: ");
		double side = read.nextDouble();
		
		answer = Math.pow(side, 3);
		System.out.printf("The volume of cube with side length %.2f is %.2f", side, answer);
		
		//
		
		
		
		
		read.close();
		
		
		
		
	}

}
